# Bamboo Money — Claude Code Setup Instructions

## Step 1: Project Structure

Create your project folder and organize the docs:

```
bamboo-money/
├── .claude/
│   └── commands/
│       └── frontend-design.md     ← Copy from /mnt/skills/public/frontend-design/SKILL.md
├── docs/
│   ├── Bamboo_Money_Experience_Design.md    ← PRIMARY design reference (colors, typography, layouts, wireframes)
│   ├── Bamboo_Money_Strategy_v2.md          ← Product strategy, competitive positioning, three pillars
│   ├── Bamboo_Money_Users_and_Integration.md ← User personas, demographics, integration architecture
│   ├── Personal_Finance_App_Market_Research.md ← Market data, CAGRs, competitive landscape
│   └── CLAUDE_CODE_PROMPT.md                ← Detailed build specifications (use for reference, not as prompt)
├── README.md
└── (project files will go here)
```

## Step 2: Copy the Frontend Design Skill

The frontend-design skill needs to be in `.claude/commands/frontend-design.md` so Claude Code applies it to all frontend work. Copy the skill file content from `SKILL.md` (the one that talks about bold aesthetic direction, distinctive typography, purposeful animations, etc.).

## Step 3: Prompt 1 — Context Setup

Copy and paste this as your first message to Claude Code:

---

```
I'm building Bamboo Money — a behavior-first personal finance app that unifies envelope budgeting, subscription management, and net worth tracking into one calm, intelligent experience. The project repo is at [YOUR_PATH_HERE]/bamboo-money and contains market research, product strategy, user research, and detailed experience design specifications.

Before writing any code, read these files for full context:
- docs/Bamboo_Money_Experience_Design.md — THIS IS THE PRIMARY DESIGN REFERENCE. Contains the complete "Organic Luxury" design system: color palette with hex values, typography (Fraunces + Plus Jakarta Sans), spacing scale, elevation/shadows, all four app views with ASCII wireframes, animation specifications, interaction patterns, onboarding flow, and component library specs.
- docs/Bamboo_Money_Strategy_v2.md — Product strategy including the three-pillar architecture (Envelopes + Subscriptions + Net Worth), competitive positioning vs YNAB/Monarch/Rocket Money/Copilot/EveryDollar, the Bamboo assistant concept (elevated and grounded, NOT quirky or chatbot-like), MVP phasing, and monetization.
- docs/Bamboo_Money_Users_and_Integration.md — Five detailed user personas with demographics and behavioral profiles, the four-view navigation (Today | Envelopes | Goals | Ask Bamboo), the assistant's voice attributes (clear, warm, grounded, calm, confident), notification system, and the integration model showing how budgeting + subscriptions + net worth connect.
- docs/Personal_Finance_App_Market_Research.md — Competitive landscape across budgeting, net worth tracking, subscription management, credit monitoring, and premium tracking markets. Market sizing and CAGR data.

Also read .claude/commands/frontend-design.md and apply its design principles to ALL frontend work. Key rules:
- Commit to a BOLD aesthetic direction before coding — no generic "AI slop"
- Use distinctive typography (never Inter, Roboto, Arial, system fonts)
- Cohesive color palette with dominant colors + sharp accents
- Purposeful animations (staggered page-load reveals, scroll-triggered effects)
- Unexpected layouts, asymmetry, atmosphere, depth
- Never purple gradients, cookie-cutter fintech design, or cold corporate aesthetics

The established design direction is "Organic Luxury" — already defined in the Experience Design doc:
- Primary: Deep forest green #1B4332
- Accent sage: #52B788
- Warm gold: #D4A574 for CTAs and highlights
- Background: Warm ivory #FAF8F5 (never cold white or gray)
- Warning: Warm terracotta #E76F51 (never harsh red)
- Cards: Pure white #FFFFFF on ivory, 16px border-radius, warm shadows
- Headers: Fraunces (soft-serif, editorial, optical sizing)
- Body: Plus Jakarta Sans (clean geometric sans-serif with warmth)
- Subtle grain/noise texture overlay on backgrounds (3-5% opacity)
- Spring-eased hover animations with gradient top-border reveal
- Dark mode: Warm charcoal #1A1D21 (never pure black)

DO NOT deviate from this established design system. Build upon it.

App summary:
- Target: Households and individuals ages 25-45, income $50K-$150K who want financial clarity without complexity
- Five target personas: The Overwhelmed Household (primary), The Intentional Builder, The Post-Mint Wanderer, The Debt Escaper, The Reluctant Upgrader
- Core product: Envelope budgeting + subscription tracking + net worth management + intelligent assistant (Bamboo)
- Navigation: Four views only — Today (home), Envelopes (spending), Goals (aspirations), Ask Bamboo (intelligence)
- Assistant voice: Calm, grounded, confident. No emoji in responses. No exclamation marks. Think premium concierge, not chatbot.
- Pricing: Free tier (5 envelopes, 2 goals) / Premium $49.99/yr (unlimited)
- Key differentiators: Envelope-first interface, proactive AI intelligence, physical-digital bridge (receipt scanning), emotional architecture (progress over perfection, calm over urgent), bilingual English/Spanish
- Competitive positioning: "A more user-friendly Monarch with a behavior-change engine" — Monarch's intelligence underneath, with simpler surface and coaching that drives action
- Tech: Next.js 14+ with App Router, React, TypeScript, Tailwind CSS

Confirm you've read and understood all docs before proceeding.
```

---

## Step 4: Prompt 2 — Build Request (Landing Page + App Shell)

After Claude Code confirms it has read the docs, send this:

---

```
Build me a Landing Page and the Core App Shell for Bamboo Money.

LANDING PAGE:
A conversion-focused marketing page that communicates Bamboo Money's value proposition and drives waitlist signups. The page should feel like the intersection of Copilot Money's precision and the Calm app's serenity — "Organic Luxury" aesthetic throughout.

Structure (detailed specs are in CLAUDE_CODE_PROMPT.md, section "Part 1: Landing Page"):
1. Hero — headline that captures the promise ("Your money, growing." or similar), subheadline explaining the product, waitlist CTA in warm gold, animated bamboo growth illustration or minimal app mockup
2. The Problem — three pain points (budgeting feels like homework / dashboards show everything but change nothing / five apps for one financial life)
3. The Solution — three pillars (Envelopes for spending control / Subscriptions for monthly optimization / Net Worth for long-term trajectory) connected by the Bamboo intelligence
4. The Assistant — 2-3 example insight cards showing the elevated voice (NOT chat bubbles — structured insight cards with subtle green left border)
5. Competitive positioning — three narrative cards: "YNAB gives every dollar a job. Bamboo gives your dollars jobs for you." / "Monarch shows you everything. Bamboo shows you what to do about it." / "Rocket Money cleans up your past. Bamboo builds your future."
6. Who it's for — persona cards for couples merging finances, people who tried budgeting and quit, goal-setters connecting daily spending to dream life, bilingual English/Spanish support
7. Pricing preview — Free vs Premium ($49.99/yr), emphasize "$4.17/month — less than half the cost of Monarch or YNAB"
8. Footer with waitlist signup, personal attribution

Key landing page moments:
- Hero animation: bamboo stalk that draws upward and sprouts leaves on page load — this is the memorable moment
- Numbers count up when scrolling into view
- Staggered fade-up reveals on scroll (50ms delays between elements)
- Subtle parallax on background grain texture (10-15px max)
- Warm gold CTA buttons with subtle scale (1.02) on hover

APP SHELL (Core Application):
Build the structural shell with navigation, layout, and all four views populated with realistic mock data. Detailed wireframes for each view are in Bamboo_Money_Experience_Design.md section 4.

Views:
1. TODAY — greeting + net worth sparkline, one Bamboo insight card, envelope summary (horizontal scroll), upcoming bills (3 rows), recent transactions (5 rows)
2. ENVELOPES — grouped by Essentials/Lifestyle/Growth, each with remaining amount + thin progress bar (4px, color-shifting green→amber→terracotta) + daily pace, expandable inline
3. GOALS — larger cards with bamboo growth visualization (vertical progress with leaf milestones at 25/50/75/100%), inline Bamboo insights per goal, "Plant a New Goal" CTA
4. ASK BAMBOO — search input at top, suggested query pills, insight feed, structured response cards (NOT chat bubbles)

Navigation:
- Mobile: bottom tab bar (64px + safe area), 4 icons with labels, subtle blur backdrop
- Desktop: sidebar (260px expanded, 72px collapsed), forest green gradient background, active state with left bar + glow

Design system components to build:
- Button (primary gold, secondary outline, ghost)
- Card (standard, envelope, insight, goal)
- Progress bar (4px, color states)
- Input (text, search)
- Navigation (bottom tab, sidebar)
- Badge/tag
- Section label (uppercase, letter-spaced)

Use realistic mock data: actual merchant names (Trader Joe's, Shell, Netflix, Amazon), realistic dollar amounts, proper dates, 6 envelopes, 3 goals, 10+ transactions. Make it feel like a real person's financial life.

The onboarding flow (6 steps, one question per screen, under 5 minutes) described in Experience Design doc section 7 — build this as a separate route (/onboarding) with the bamboo illustration growing across steps.

Build quality standard: this should look like it could be shown to investors, put in front of beta testers, or featured on Product Hunt. Every pixel matters.
```

---

## Step 5: Follow-Up Prompts (After Initial Build)

Once the landing page and app shell are built, use these follow-ups to refine:

**Polish pass:**
```
Review the entire build against docs/Bamboo_Money_Experience_Design.md. Check: Are all colors using the exact hex values from the design system? Is Fraunces used for all headlines and stat values? Is Plus Jakarta Sans used for all body text? Is the grain texture applied to background surfaces? Do hover animations use spring easing (cubic-bezier 0.34, 1.56, 0.64, 1)? Are card shadows using the warm-toned values? Fix any deviations.
```

**Dark mode:**
```
Implement dark mode using the dark palette from the Experience Design doc (--bg-primary: #1A1D21, NOT pure black). Use Tailwind's class-based dark mode strategy. Add a toggle in settings. The sidebar should shift to deeper forest tones. All text should use warm off-white (#E8E4DF), never pure white.
```

**Spanish language:**
```
Add i18n support using next-intl or a similar library. Create English and Spanish translation files. Translate all UI labels, navigation, onboarding flow, and landing page content. The assistant's example insights should also have Spanish versions. Default to English with a language switcher in settings.
```

**Responsive refinement:**
```
Test and refine the mobile experience (< 768px). Bottom navigation should have 64px height plus safe area inset. Envelope cards should be full-width. The Today view's envelope summary should horizontal-scroll. Goal cards should stack vertically. The Ask Bamboo input should be sticky at top on scroll. Ensure touch targets are minimum 44px.
```

---

## Notes

- The `CLAUDE_CODE_PROMPT.md` file in docs/ contains extremely detailed specs for both the landing page and app shell — Claude Code should reference it for details not covered in the prompts above
- If Claude Code asks about design decisions, always defer to `Bamboo_Money_Experience_Design.md` first
- The three design principles to reinforce if things go off-track: **Calm Authority, Organic Warmth, Progressive Depth**
- If the output starts looking "generic fintech" (blue gradients, cold whites, Inter font, stock-photo energy), stop and redirect back to the Organic Luxury direction
- The goal visualization (bamboo stalk with leaf milestones) is the signature visual moment — invest time in making it feel organic and alive, not mechanical
